<?php

if ( ! isset( $color_scheme[2] ) ) {

	$custom_css = '';

} else {

	$custom_css = "";

}