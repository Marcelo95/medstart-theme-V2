<?php

namespace Nextend\Framework\Form\Element\Text;

use Nextend\Framework\Form\Element\Text;

class Disabled extends Text {

    protected $attributes = array('disabled' => 'disabled');
}